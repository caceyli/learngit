# Copyright (c) Verax Systems. All rights reserved.
# This folder contains SNMP record files. 
# In order to prepare SNMP record file reflecting actual SNMP agent available at given IP address, 
# use Linux SNMP tools and issue the following command:
# snmpwalk -On -Oe -OU -v2c -c public address > snmprecordfile.txt
# Provide the correct read only community string, IP address and file name. Refer to snmpwalk manual for the details.
# Please ensure if each line in the resulting file is correctly formatted.


