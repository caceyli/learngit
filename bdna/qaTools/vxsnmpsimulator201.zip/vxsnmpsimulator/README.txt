Verax SNMP Agent Simulator


Introduction
====================================================== 
Verax SNMP agent simulator is a tool that can simulate multiple SNMPv1/v2c agents on
a single host on standard 161 port through multi-netting. It allows IT personnel to
build virtual, simulated networks of devices without purchasing any additional
hardware, for instance for testing purposes. Individual simulated agent responses can
be initially retrieved from existing devices and modified at runtime by user defined rules. 


Prerequisites
====================================================== 
- Windows or Linux system
- Java 1.6 installed
- Network card with a static IP address


Package contents
====================================================== 
This .zip file contains:
- Simulator binaries (in the ./jar directory): the simulator itself and the management consoles (CLI and web based)  
- Sample device configuration files (in the ./device directory) for Ciscos, Linux
  hosts, etc.   
  Additional simulated device files can be created using Unix SNMP walk on real
  devices and applying changes (see .\device\README.txt for detailed instructions).

Installation
====================================================== 
1. Unzip the simulator files to 
    /opt/verax/vxsnmpsimulator (Linux)
    %ProgramFiles%\vxsnmpsimulator (Windows)
   IMPORTANT: The installation & configuration on Windows should be performed with
              administrative privileges ("Run as Administrator").
2. IMPORTANT: Move the simulatord.conf from the installation directory to 
   /etc/verax.d/ on Linux or %SystemRoot%\etc\verax.d\ on Windows.
   (this location cannot be changed).
3. Open the simulatord.conf in the editor and follow the instructions inside.  
4. Open the command line shell as administrator/root ("Run as administrator" on
   Windows), go to the installation directory and run:
     * simulator.bat (Windows)
     * /etc/init.d/simulatord start (Linux)
 

Documentation
====================================================== 
- User guide: http://www.veraxsystems.com/pubfiles/vxsnmpsimulator-userguide.pdf
- HOWTO: http://www.veraxsystems.com/pubfiles/how-to-simulate-network-devices.pdf


License
====================================================== 
Verax SNMP Simulator is provided "as is" with no warranty, free of charge under the
license which can be found in LICENSE.txt file provided along with this package. Free
usage of this tool is limited to 4 SNMP agents. 
For unlimited license contact Verax Systems.



Copyright (c) Verax Systems. All rights reserved.

