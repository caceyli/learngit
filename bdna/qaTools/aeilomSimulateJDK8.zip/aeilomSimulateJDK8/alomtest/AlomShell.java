package com.alomtest;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import org.apache.sshd.common.Factory;
import org.apache.sshd.server.Command;
import org.apache.sshd.server.Environment;
import org.apache.sshd.server.ExitCallback;

public class AlomShell implements Factory, Command, Runnable{

	private InputStream in ;

    private OutputStream out;

    private OutputStream err;

    private ExitCallback callback;

    private Thread thread;

    private static final String prompt = "sc> ";

    
    @Override
    public Command create()
    {
        return this;
    }


    @Override
    public void start(Environment env) throws IOException
    {
        thread = new Thread(this, "MyShell");
        thread.start();
    }

@Override
    public void run()
    {
        try
        {   
        	System.out.println("sdfsdfsd");
   //     	out.write("\n\r\n\r".getBytes());
   //     	out.write("Copyright 2007 Sun Microsystems, Inc.  All rights reserved.\n\r".getBytes());
   //     	out.write("Use is subject to license terms.\n\r".getBytes());
   //     	out.write("\n\r\n\r".getBytes());
   //     	out.write("Sun(tm) Advanced Lights Out Manager CMT v1.3.1 (-a)\n\r\n\r".getBytes());
    //    	out.flush();
        	boolean flag = false;
        	while (true) {        		
        		if (flag == true) {
        			System.out.println("============");
        			break;
        		}
        		StringBuffer userBuffer = new StringBuffer();
        		StringBuffer passwdbuffer = new StringBuffer();
                out.write("Please login: ".getBytes());
                out.flush();
                while (true){
                    int c = in.read();
                    if (c == '\r' || c == '\n')
                        break;
                    
                    out.write(c);
                    out.flush();
                    userBuffer.append((char)c);
                }
                out.write('\r');
                out.write('\n');
                String userString = userBuffer.toString(); 
                if (userString != null && !userString.equals("")) {
                	while (true) {
                		passwdbuffer = new StringBuffer();
                        out.write("Please Enter password: ".getBytes());
                        out.flush();
                        while (true){
                            int c = in.read();
                            if (c == '\r' || c == '\n')
                                break;
                            
                            out.write("*".getBytes());
                            out.flush();
                            passwdbuffer.append((char)c);
                        }
                        out.write('\r');
                        out.write('\n');
                        String passwdString = passwdbuffer.toString(); 
                        if (passwdString != null && passwdString.equals("n1md@345") && userString.equals("root")) {
                        	flag = true;
                        	break;
                        } else {
                        //	out.write("\r\n\r\n".getBytes());
                        	out.write("\r\nInvalid login\r\nPlease Login:".getBytes());
                        	out.flush();
                        	while (true) {
                        		
                        	}

                        }
                	}
                	
                } 
                
        	} 
            out.write('\r');
            out.write('\n');
            out.write('\r');
            out.write('\n');
            out.flush();
            while (true)
            {
                StringBuffer buffer = new StringBuffer();
                out.write(prompt.getBytes());
                out.flush();
                while (true)
                {
                    int c = in.read();
                    if (c == '\r' || c == '\n')
                        break;
                    
                    out.write(c);
                    out.flush();
      //              System.out.println("yes!");
                    buffer.append((char)c);
                }
      //          out.write('\r');
       //         out.write('\n');
                String line = buffer.toString();
                //information is from bug 27070 comment #14:Advanced Lights Out Manager 1.6.5/1.3.1
                if (line != null && line.trim().equals("showplatform -v")) {
                	out.write("\n\rSUNW,Sun-Fire-T2000\n\r\n\r".getBytes());
                	out.write("Chassis Serial Number: 0837NNN030\n\r\n\r".getBytes());
                	out.write("Domain Status: 0710TL50Z1\n\r".getBytes());
                	out.write("------ ------\n\r".getBytes());
                	out.write("S0 Running".getBytes());
                	
                } else if  (line != null && line.trim().equals("showsc sys_enetaddr")) {
                	out.write("\n\r94:DE:80:C4:65:B0".getBytes());
                } else if  (line != null && line.trim().equals("shownetwork")) {
                	out.write("\n\rSC network configuration is:\n\r".getBytes());
                	out.write("IP Address: 192.168.8.211\n\r".getBytes());
                	out.write("Gateway address: 192.168.8.3\n\r".getBytes());
                	out.write("Netmask: 255.255.252.0\n\r".getBytes());
                	out.write("Ethernet address: 00:14:4f:ed:0f:db".getBytes());
                } else if  (line != null && line.trim().equals("showsc version")) {
                	out.write("\n\rAdvanced Lights Out Manager CMT v1.7.10".getBytes());
                } else if  (line != null && line.trim().equals("showsc sys_hostname")) {
                	out.write("\n\r    ".getBytes());
                } else if  (line != null && line.trim().equalsIgnoreCase("logout")) {
                    return;
                } else if  (line != null && !line.trim().equals("")) {
                	out.write("\n\rInvalid command.  Type 'help' for list of commands.".getBytes());                
                //	out.write(line.getBytes());
                }
                out.write('\r');
                out.write('\n');
                out.flush();
            } 
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return;
        } catch (Exception e1) {
        	e1.printStackTrace();
        }
        finally
        {
            callback.onExit(0);
        }

    }


@Override
public void setInputStream(InputStream in) {
	// TODO Auto-generated method stub
	this.in = in;
	
}


@Override
public void setOutputStream(OutputStream out) {
	// TODO Auto-generated method stub
	this.out = out;
	
}


@Override
public void setErrorStream(OutputStream err) {
	// TODO Auto-generated method stub
	this.err = err;
	
}


@Override
public void setExitCallback(ExitCallback callback) {
	// TODO Auto-generated method stub
	this.callback = callback;
	
}


@Override
public void destroy() {
	// TODO Auto-generated method stub
	
	
}
}
