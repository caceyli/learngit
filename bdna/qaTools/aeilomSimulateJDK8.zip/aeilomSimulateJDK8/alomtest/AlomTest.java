package com.alomtest;

import java.io.IOException;
import java.util.EnumSet;

import org.apache.sshd.SshServer;
import org.apache.sshd.common.keyprovider.FileKeyPairProvider;
import org.apache.sshd.common.util.SecurityUtils;
import org.apache.sshd.server.keyprovider.PEMGeneratorHostKeyProvider;
import org.apache.sshd.server.keyprovider.SimpleGeneratorHostKeyProvider;
import org.apache.sshd.server.shell.ProcessShellFactory;

public class AlomTest {
    
	//private static final String WELCOME = "Copyright 2007 Sun Microsystems, Inc.  All rights reserved.\n" +
//			"Use is subject to license terms.\n\n\n" + "Sun(tm) Advanced Lights Out Manager 1.6.5 (-a)\n\n";
	/**
	 * @param args
	 */
	public static void main(String[] args)
    {
        SshServer sshd = SshServer.setUpDefaultServer();
        sshd.setHost("192.168.10.134");
        sshd.setPort(22);
        if (SecurityUtils.isBouncyCastleRegistered()) {// ����Ự��ȫУ����Ϣ��key.pem��key.serΪ�ļ���  
            sshd.setKeyPairProvider(new PEMGeneratorHostKeyProvider("key.pem"));  
        }  
        else {  
            sshd.setKeyPairProvider(new SimpleGeneratorHostKeyProvider("key.ser"));  
        } 
      //  sshd.setKeyPairProvider(new FileKeyPairProvider(new String[] {"key/my_host_key" }));
        sshd.setPasswordAuthenticator(new MyPasswordAuthenticator());

        sshd.setShellFactory(new AlomShell());
    //    sshd.getProperties().put(SshServer.WELCOME_BANNER, WELCOME);

         
        try
        {
            sshd.start();
            
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

}
