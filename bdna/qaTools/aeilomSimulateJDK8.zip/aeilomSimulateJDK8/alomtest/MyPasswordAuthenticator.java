package com.alomtest;

import org.apache.sshd.server.PasswordAuthenticator;
import org.apache.sshd.server.session.ServerSession;

public class MyPasswordAuthenticator implements  PasswordAuthenticator{

	@Override
	public boolean authenticate(String username, String password,
			ServerSession session) {
		// TODO Auto-generated method stub
		
/*		if (username .equals("root") && password .equals("n1md@345")) {
			System.out.println("test  o!!!");
			return true;
		}*/
		System.out.println("test!!!");
		return true;
	}

}
